base = int(input("Digite um valor inteiro para a base.\n")); expoente = int(input("Digite um valor inteiro para o expoente.\n"))

print ("{} elevado a {} é {}." .format (base, expoente, base ** expoente))