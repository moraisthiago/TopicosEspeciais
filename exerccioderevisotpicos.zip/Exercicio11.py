N = int(input())

print ("O número {} possui {} dígito(s)." .format (N, len(str(N))))