N = int(input())
somatorio = int()

for i in range(1, N + 1):
	somatorio += i
	
print ("O somatório de {} é {}." .format (N, somatorio))